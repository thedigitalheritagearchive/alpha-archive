                                                
/*
**  Defaults For Programmable BASIC Keywords.
**
**  Copyright 1993-2000 by Paul D. Burgin. All rights reserved.
*/
                                           
#include "build.h"

/* Default strings for function key macros. */
unsigned char presets[11][PRESET_LEN+2] =
{
	/* Strings for Alt-F1 to Alt-F10. */
	"cload^m",	"csave^m",	"cloadm^m",	"csavem\"\",",
	"circle(",	"line(",	"pset(",	"preset(",

	"left$(",	"right$(",

	/* The next string is F6. */
	""
};

/* Default strings for letter key macros. */
unsigned char keywords[26][11] =
{
	"and",
	"gosub",
	"color",
	"draw",
	"else",
	"for",
	"goto",
	"hex$(",
	"input",
	"joystk(",
	"poke",
	"list^m",
	"pmode",
	"next",
	"or",
	"paint(",
	"edit",
	"run^m",
	"step",
	"then",
	"return",
	"val(",
	"screen",
	"exec",
	"inkey$",
	"peek("
};

